package ce326.hw3;

public class Connect4Game {
    private Board board;
    private Minmax ai;
    private int difficulty;
    public int currentPlayer;
    public int aiMove;
    private int winner = -1;

    public Connect4Game(int depth, int firstPlayer) {
        board = new Board();
        ai = new Minmax();
        difficulty = depth;
        currentPlayer = firstPlayer;
    }

    public int getWinner() {
        return winner;
    }

    public String getDifficulty() {
        if (difficulty == Minmax.TRIVIAL) {
            return "Trivial";
        }
        else if (difficulty == Minmax.MEDIUM) {
            return "Medium";
        }
        else if (difficulty == Minmax.HARD) {
            return "Hard";
        }

        return "";
    }

    public int Play(int playerMove) {
        if (currentPlayer == Board.RED) {
            int row = board.makeMove(playerMove, Board.RED);

            if (row == -1) {
                return row;
            }
            
            if (board.isGameOver()) {
                winner = board.getWinner();
            }

            //board.displayBoard();

            currentPlayer = Board.YELLOW;
            return row;
        }
        
        if (currentPlayer == Board.YELLOW) {
            aiMove = ai.findBestMove(board, difficulty);
            int row = board.makeMove(aiMove, Board.YELLOW);
        
            if (board.isGameOver()) {
                winner = board.getWinner();
            }

            //board.displayBoard();

            currentPlayer = Board.RED;
            return row;
        }

        return -1;
    }

    public void reset(int firstPlayer) {
        board.resetBoard();
        winner = -1;
        currentPlayer = firstPlayer;
    }
}
