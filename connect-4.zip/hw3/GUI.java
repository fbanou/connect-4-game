package ce326.hw3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Date;
import java.util.Collections;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.DOMException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class GUI extends JFrame {
    private boolean gamePaneleOn = true;
    private int firstPlayer = 2;
    private Connect4Game game = null;

    private ImageIcon iconEmpty = null;
    private ImageIcon iconRed = null;
    private ImageIcon iconYellow = null;

    private JList<String> historyList;
    private List<String> completedGames;

    private String gameId = null;
    private List<Move> moves;

    private int countGames = 0;

    private int currentIndex;
    private Timer timer;

    private boolean historyOn = false;

    public void createGUI() {
        JFrame frame = new JFrame("Connect-4 Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(750, 650));
        
        JPanel gamePanel = new JPanel(new GridLayout(6, 7));
        JButton[][] buttons = new JButton[6][7];
        
        JMenuBar menuBar = new JMenuBar();
        JMenu gameMenu = new JMenu("New Game");
        JMenu firstPlayerMenu = new JMenu("1st Player");
        JMenu historyMenu = new JMenu("History");
        JMenu helpMenu = new JMenu("Help");

        JMenuItem showHistoryItem = new JMenuItem("Show History");
        historyMenu.add(showHistoryItem);

        JMenuItem trivialMenuItem = new JMenuItem("Trivial");
        JMenuItem mediumMenuItem = new JMenuItem("Medium");
        JMenuItem hardMenuItem = new JMenuItem("Hard");

        JRadioButtonMenuItem aiRadioButton = new JRadioButtonMenuItem("AI", true);
        JRadioButtonMenuItem youRadioButton = new JRadioButtonMenuItem("You");
        
        ButtonGroup playerButtonGroup = new ButtonGroup();
        playerButtonGroup.add(aiRadioButton);
        playerButtonGroup.add(youRadioButton);
        
        firstPlayerMenu.add(aiRadioButton);
        firstPlayerMenu.add(youRadioButton);

        gameMenu.add(trivialMenuItem);
        gameMenu.addSeparator();
        gameMenu.add(mediumMenuItem);
        gameMenu.addSeparator();
        gameMenu.add(hardMenuItem);

        menuBar.add(gameMenu);
        menuBar.add(firstPlayerMenu);
        menuBar.add(historyMenu);
        menuBar.add(helpMenu);

        completedGames = new ArrayList<>();
        historyList = new JList<>();
        JScrollPane historyScrollPane = new JScrollPane(historyList);
        historyScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        historyScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        JPanel historyPanel = new JPanel();
        historyPanel.setLayout(new BorderLayout());
        historyPanel.add(historyScrollPane, BorderLayout.CENTER);

        iconEmpty = new ImageIcon("icons/empty.png");
        iconRed = new ImageIcon("icons/red.png");
        iconYellow = new ImageIcon("icons/yellow.png");

        String userHome = System.getProperty("user.home");
        File connect4Directory = new File(userHome, "connect4");

        if (!connect4Directory.exists()) {
            boolean created = connect4Directory.mkdir();

            if (created) {
                System.out.println("The 'connect4' directory has been created.");
            } else {
                System.err.println("Failed to create the 'connect4' directory.");
            }
        }


        for(int row = 0; row < Board.ROWS; row++) {
            for (int col = 0; col < Board.COLUMNS; col++) {
                final int currentCol = col;

                buttons[row][col] = new JButton();
                buttons[row][col].setIcon(iconEmpty);
                buttons[row][currentCol].addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        if (e.getClickCount() == 2) {
                            if (game == null) {
                                JOptionPane.showMessageDialog(frame, "Select difficulty first", "", JOptionPane.WARNING_MESSAGE);
                            }
                            else if (game.getWinner() != -1) {
                                JOptionPane.showMessageDialog(frame, "Select difficulty for new game", "New Game", JOptionPane.INFORMATION_MESSAGE);
                            }
                            else if (historyOn) {
                                JOptionPane.showMessageDialog(frame, "Game in progress!", "History", JOptionPane.INFORMATION_MESSAGE);
                            }
                            else {
                                if (game.currentPlayer == Board.RED) {
                                    int row = game.Play(currentCol);

                                    if (row == -1) {
                                        JOptionPane.showMessageDialog(frame, "Invalid move", "Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                    else {
                                        buttons[row][currentCol].setIcon(iconRed);
                                        Move move = new Move("P", row, currentCol);
                                        moves.add(move);

                                        if (game.getWinner() == Board.RED) {
                                            JOptionPane.showMessageDialog(frame, "You win!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                                            saveGameToHistory(gameId, "P", game.getDifficulty());

                                            countGames++;
                                            String fileName = userHome + File.separator + "connect4" + File.separator + countGames + ".xml";
                                            createGameLogXML(fileName, gameId, "P", moves);
                                        }
                                        else if (game.getWinner() == Board.EMPTY) {
                                            JOptionPane.showMessageDialog(frame, "Draw!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                                            saveGameToHistory(gameId, "Draw", game.getDifficulty());

                                            countGames++;
                                            String fileName = userHome + File.separator + "connect4" + File.separator + countGames + ".xml";
                                            createGameLogXML(fileName, gameId, "Draw", moves);
                                        }
                                    }
                                }
                        
                                if (game.currentPlayer == Board.YELLOW) {
                                    int row = game.Play(-1);
                                    buttons[row][game.aiMove].setIcon(iconYellow);
                                    Move move = new Move("AI", row, game.aiMove);
                                    moves.add(move);

                                    if (game.getWinner() == Board.YELLOW) {
                                        JOptionPane.showMessageDialog(frame, "You lost!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                                        saveGameToHistory(gameId, "AI", game.getDifficulty());

                                        countGames++;
                                        String fileName = userHome + File.separator + "connect4" + File.separator + countGames + ".xml";
                                        createGameLogXML(fileName, gameId, "AI", moves);
                                    }
                                    else if (game.getWinner() == Board.EMPTY) {
                                        JOptionPane.showMessageDialog(frame, "Draw!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                                        saveGameToHistory(gameId, "Draw", game.getDifficulty());

                                        countGames++;
                                        String fileName = userHome + File.separator + "connect4" + File.separator + countGames + ".xml";
                                        createGameLogXML(fileName, gameId, "Draw", moves);
                                    }
                                }
                            }
                        }
                    }
                });

                buttons[row][col].addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyPressed(KeyEvent e) {
                        if (game == null) {
                            JOptionPane.showMessageDialog(frame, "Select difficulty first", "", JOptionPane.WARNING_MESSAGE);
                        }
                        else if (game.getWinner() != -1) {
                            JOptionPane.showMessageDialog(frame, "Select difficulty for new game", "New Game", JOptionPane.INFORMATION_MESSAGE);
                        }
                        else if (historyOn) {
                            JOptionPane.showMessageDialog(frame, "Game in progress!", "History", JOptionPane.INFORMATION_MESSAGE);
                        }
                        else {
                            int keyCode = e.getKeyCode();

                            if (keyCode >= KeyEvent.VK_0 && keyCode <= KeyEvent.VK_6) {
                                int column = keyCode - KeyEvent.VK_0;
                            
                                if (game.currentPlayer == Board.RED) {
                                    int row = game.Play(column);

                                    if (row == -1) {
                                        JOptionPane.showMessageDialog(frame, "Invalid move", "Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                    else {
                                        buttons[row][column].setIcon(iconRed);
                                        Move move = new Move("P", row, column);
                                        moves.add(move);
                                        
                                        if (game.getWinner() == Board.RED) {
                                            JOptionPane.showMessageDialog(frame, "You win!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                                            saveGameToHistory(gameId, "P", game.getDifficulty());

                                            countGames++;
                                            String fileName = userHome + File.separator + "connect4" + File.separator + countGames + ".xml";
                                            createGameLogXML(fileName, gameId, "P", moves);
                                        }
                                        else if (game.getWinner() == Board.EMPTY) {
                                            JOptionPane.showMessageDialog(frame, "Draw!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                                            saveGameToHistory(gameId, "Draw", game.getDifficulty());

                                            countGames++;
                                            String fileName = userHome + File.separator + "connect4" + File.separator + countGames + ".xml";
                                            createGameLogXML(fileName, gameId, "Draw", moves);
                                        }
                                    }
                                }

                                if (game.currentPlayer == Board.YELLOW) {
                                    int row = game.Play(column);
                                    buttons[row][game.aiMove].setIcon(iconYellow);
                                    Move move = new Move("AI", row, game.aiMove);
                                    moves.add(move);

                                    if (game.getWinner() == Board.YELLOW) {
                                        JOptionPane.showMessageDialog(frame, "You lost!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                                        saveGameToHistory(gameId, "AI", game.getDifficulty());

                                        countGames++;
                                        String fileName = userHome + File.separator + "connect4" + File.separator + countGames + ".xml";
                                        createGameLogXML(fileName, gameId, "AI", moves);
                                    }
                                    else if (game.getWinner() == Board.EMPTY) {
                                        JOptionPane.showMessageDialog(frame, "Draw!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                                        saveGameToHistory(gameId, "Draw", game.getDifficulty());

                                        countGames++;
                                        String fileName = userHome + File.separator + "connect4" + File.separator + countGames + ".xml";
                                        createGameLogXML(fileName, gameId, "Draw", moves);
                                    }
                                }
                            }
                        }
                    }
                });

                gamePanel.add(buttons[row][col]);
            }
        }

        aiRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstPlayer = 2;
                JOptionPane.showMessageDialog(frame, "First player is AI", "First player", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        youRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstPlayer = 1;
                JOptionPane.showMessageDialog(frame, "First player is You","First player", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        trivialMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (historyOn) {
                    timer.stop();
                    historyOn = false;
                }

                if (!gamePaneleOn) {
                    frame.getContentPane().remove(historyPanel);
                    frame.getContentPane().add(gamePanel);
                    frame.revalidate();
                    frame.repaint();
                    gamePaneleOn = true;
                }

                game = new Connect4Game(Minmax.TRIVIAL, firstPlayer);
                resetBoard(buttons);

                gameId = getTimestamp();
                moves = new ArrayList<>();

                if (game.currentPlayer == Board.YELLOW) {
                    int row = game.Play(-1);
                    buttons[row][game.aiMove].setIcon(iconYellow);
                    Move move = new Move("AI", row, game.aiMove);
                    moves.add(move);
                }
            }
        });
        
        mediumMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (historyOn) {
                    timer.stop();
                    historyOn = false;
                }

                if (!gamePaneleOn) {
                    frame.getContentPane().remove(historyPanel);
                    frame.getContentPane().add(gamePanel);
                    frame.revalidate();
                    frame.repaint();
                    gamePaneleOn = true;
                }

                game = new Connect4Game(Minmax.MEDIUM, firstPlayer);
                resetBoard(buttons);

                gameId = getTimestamp();
                moves = new ArrayList<>();
                
                if (game.currentPlayer == Board.YELLOW) {
                    int row = game.Play(-1);
                    buttons[row][game.aiMove].setIcon(iconYellow);
                    Move move = new Move("AI", row, game.aiMove);
                    moves.add(move);
                }
            }
        });
        
        hardMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (historyOn) {
                    timer.stop();
                    historyOn = false;
                }

                if (!gamePaneleOn) {
                    frame.getContentPane().remove(historyPanel);
                    frame.getContentPane().add(gamePanel);
                    frame.revalidate();
                    frame.repaint();
                    gamePaneleOn = true;
                }

                game = new Connect4Game(Minmax.HARD, firstPlayer);
                resetBoard(buttons);

                gameId = getTimestamp();
                moves = new ArrayList<>();
                
                if (game.currentPlayer == Board.YELLOW) {
                    int row = game.Play(-1);
                    buttons[row][game.aiMove].setIcon(iconYellow);
                    Move move = new Move("AI", row, game.aiMove);
                    moves.add(move);
                }
            }
        });

        showHistoryItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showHistory();
                resetBoard(buttons);

                if (game != null) {
                    game.reset(firstPlayer);
                }

                frame.getContentPane().remove(gamePanel);
                frame.getContentPane().add(historyPanel);
                frame.revalidate();
                frame.repaint();
                gamePaneleOn = false;
            }
        });

        historyList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int selectedIndex = historyList.getSelectedIndex();

                        frame.getContentPane().remove(historyPanel);
                        frame.getContentPane().add(gamePanel);
                        frame.revalidate();
                        frame.repaint();
                        gamePaneleOn = true;

                    if (selectedIndex != -1) {
                        resetBoard(buttons);
                        int name = historyList.getModel().getSize() - selectedIndex;
                        String fileName = userHome + File.separator + "connect4" + File.separator + name + ".xml";
                        historyOn = true;
                        readGameLogXML(fileName, frame, buttons, gamePanel);
                    }
                }
            }
        });
        
        frame.setJMenuBar(menuBar);
        frame.getContentPane().add(gamePanel);
        frame.pack();
        frame.setVisible(true);
    }

    public void resetBoard(JButton[][] buttons) {
        for(int row = 0; row < Board.ROWS; row++) {
            for (int col = 0; col < Board.COLUMNS; col++) {
                buttons[row][col].setIcon(iconEmpty);
            }
        }
    }

    private void saveGameToHistory(String timestamp, String result, String difficulty) {
        String gameInfo = timestamp + "  L: " + difficulty + "  W: " + result;
        completedGames.add(gameInfo);
    }

    private void showHistory() {
        Collections.reverse(completedGames);
        String[] historyArray = completedGames.toArray(new String[completedGames.size()]);
        historyList.setListData(historyArray);
        Collections.reverse(completedGames);
    }

    private String getTimestamp() {
        Calendar calendar = Calendar.getInstance();

        Date currentDate = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd - HH:mm");

        String formattedDate = dateFormat.format(currentDate);

        return formattedDate;
    }

    private void createGameLogXML(String fileName, String gameId, String winner, List<Move> moves) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.newDocument();
            
            Element rootElement = doc.createElement("game");
            doc.appendChild(rootElement);
            
            Element gameIdElement = doc.createElement("gameId");
            gameIdElement.appendChild(doc.createTextNode(gameId));
            rootElement.appendChild(gameIdElement);
            
            Element winnerElement = doc.createElement("winner");
            winnerElement.appendChild(doc.createTextNode(winner));
            rootElement.appendChild(winnerElement);
            
            Element movesElement = doc.createElement("moves");
            for (Move move : moves) {
                Element moveElement = doc.createElement("move");
            
                Element playerElement = doc.createElement("player");
                playerElement.appendChild(doc.createTextNode(move.getPlayer()));
                moveElement.appendChild(playerElement);

                Element rowElement = doc.createElement("row");
                rowElement.appendChild(doc.createTextNode(String.valueOf(move.getRow())));
                moveElement.appendChild(rowElement);
                
                Element columnElement = doc.createElement("column");
                columnElement.appendChild(doc.createTextNode(String.valueOf(move.getColumn())));
                moveElement.appendChild(columnElement);
                
                movesElement.appendChild(moveElement);
            }
            rootElement.appendChild(movesElement);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(fileName));
            transformer.transform(source, result);
            
            System.out.println("Game log saved to " + fileName);
        } catch (ParserConfigurationException | TransformerException | DOMException e) {
            e.printStackTrace();
        }
    }

    private void readGameLogXML(String fileName, JFrame frame, JButton[][] buttons, JPanel gamePanel) {
        List<Move> moves = new ArrayList<>();

        try {
            File file = new File(fileName);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);

            Element rootElement = doc.getDocumentElement();

            //String gameId = rootElement.getElementsByTagName("gameId").item(0).getTextContent();
            //String winner = rootElement.getElementsByTagName("winner").item(0).getTextContent();

            NodeList moveNodes = rootElement.getElementsByTagName("move");
            for (int i = 0; i < moveNodes.getLength(); i++) {
                Node moveNode = moveNodes.item(i);
                if (moveNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element moveElement = (Element) moveNode;
                    String player = moveElement.getElementsByTagName("player").item(0).getTextContent();
                    int row = Integer.parseInt(moveElement.getElementsByTagName("row").item(0).getTextContent());
                    int column = Integer.parseInt(moveElement.getElementsByTagName("column").item(0).getTextContent());
    
                    Move move = new Move(player, row, column);
                    moves.add(move);
                }
            }

            paintCanvas(moves, frame, buttons, gamePanel);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void paintCanvas(List<Move> moves, JFrame frame, JButton[][] buttons, JPanel gamePanel) {
        currentIndex = 0;

        timer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentIndex < moves.size()) {
                    for (int i = 0; i <= currentIndex; i++) {
                        if (moves.get(i).getPlayer().equals("P")) {
                            buttons[moves.get(i).getRow()][moves.get(i).getColumn()].setIcon(iconRed);
                        }
                        else if (moves.get(i).getPlayer().equals("AI")) {
                            buttons[moves.get(i).getRow()][moves.get(i).getColumn()].setIcon(iconYellow);
                        }
                    }
                    frame.getContentPane().add(gamePanel);
                    frame.revalidate();
                    frame.repaint();
                    currentIndex++;
                } else {
                    timer.stop();
                }
            }
        });

        timer.start();
    }
}
