package ce326.hw3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameHistoryApp {
    private JFrame frame;
    private JPanel gamePanel;
    private JList<String> historyList;
    private CardLayout cardLayout;

    public GameHistoryApp() {
        frame = new JFrame("Game History");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        cardLayout = new CardLayout();
        frame.setLayout(cardLayout);

        gamePanel = new JPanel();
        gamePanel.setBackground(Color.WHITE);
        // Προσθέστε τον καμβά του παιχνιδιού και τα κουμπιά εδώ.
        frame.add(gamePanel, "GamePanel");

        historyList = new JList<>();
        // Προσθέστε τα ολοκληρωμένα παιχνίδια στη λίστα εδώ.
        frame.add(new JScrollPane(historyList), "HistoryList");

        JButton viewHistoryButton = new JButton("Show History");
        viewHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(frame.getContentPane(), "HistoryList");
            }
        });

        JButton backToGameButton = new JButton("Back to Game");
        backToGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(frame.getContentPane(), "GamePanel");
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(viewHistoryButton);
        buttonPanel.add(backToGameButton);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GameHistoryApp();
            }
        });
    }
}

