package ce326.hw3;

public class Connect4 {
    private static GUI connect4GUI;
    public static void main(String[] args) {
        connect4GUI = new GUI();
        connect4GUI.createGUI();
    }
}