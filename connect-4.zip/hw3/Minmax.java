package ce326.hw3;

public class Minmax {
    public static final int TRIVIAL = 1;
    public static final int MEDIUM = 3;
    public static final int HARD = 5;

    public static final int EMPTY = 0;
    public static final int RED = 1;
    public static final int YELLOW = 2;
    private static final int WINNING_SCORE = 10000;

    public int findBestMove(Board board, int difficulty) {
        int bestMove = -1;
        int bestScore = Integer.MIN_VALUE;
        int depth = 1;
        
        if (difficulty == MEDIUM) {
            depth = 3;
        } else if (difficulty == HARD) {
            depth = 5;
        }

        for (int move = 0; move < Board.COLUMNS; move++) {
            Board new_board = board.cloneBoard();
            if (!new_board.checkFullColumn(move)) {
                new_board.makeMove(move, YELLOW);
                int score = minValue(new_board, depth - 1, Integer.MIN_VALUE, Integer.MAX_VALUE);

                if (score > bestScore) {
                    bestScore = score;
                    bestMove = move;
                }
            }
        }

        return bestMove;
    }

    private int maxValue(Board board, int depth, int alpha, int beta) {
        if (depth == 0 || board.isGameOver()) {
            return evaluate(board);
        }

        int maxScore = Integer.MIN_VALUE;
        
        for (int move = 0; move < Board.COLUMNS; move++) {
            Board new_board = board.cloneBoard();

            if (!new_board.checkFullColumn(move)) {
                new_board.makeMove(move, YELLOW);
                int score = minValue(new_board, depth - 1, alpha, beta);
                maxScore = Math.max(maxScore, score);
                alpha = Math.max(alpha, score);

                if (alpha >= beta) {
                    break;
                }
            }
        }

        return maxScore;
    }

    private int minValue(Board board, int depth, int alpha, int beta) {
        if (depth == 0 || board.isGameOver()) {
            return evaluate(board);
        }

        int minScore = Integer.MAX_VALUE;

        for (int move = 0; move < Board.COLUMNS; move++) {
            Board new_board = board.cloneBoard();

            if (!new_board.checkFullColumn(move)) {
                new_board.makeMove(move, RED);
                int score = maxValue(new_board, depth - 1, alpha, beta);
                minScore = Math.min(minScore, score);
                beta = Math.min(beta, score);

                if (beta <= alpha) {
                    break;
                }
            }
        }
        
        return minScore;
    }

    private int evaluate(Board board) {
		int redScore = 0;
		int yellowScore = 0;

		if (board.checkForWinner()) {
			if (board.getWinner() == RED) {
				return -WINNING_SCORE;
			} else if (board.getWinner() == YELLOW) {
                return WINNING_SCORE;
			}
		}

		for (int i = 1; i < 4; i++) {
			redScore += board.countStreaks(i, RED) * Math.pow(4, i - 1);
			yellowScore += board.countStreaks(i, YELLOW) * Math.pow(4, i - 1);
		}

		return yellowScore - redScore;
	}
}
