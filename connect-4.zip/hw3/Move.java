package ce326.hw3;

public class Move {
    private String player;
    private int column;
    private int row;

    public Move(String player, int row, int column) {
        this.player = player;
        this.column = column;
        this.row = row;
    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }
}
