package ce326.hw3;

public class Board {

    public static final int ROWS = 6;
    public static final int COLUMNS = 7;
	public static final int EMPTY = 0;
    public static final int RED = 1;
    public static final int YELLOW = 2;
    
	private int[][] board;
	private int winner = -1;

    public Board() {
        board = new int[ROWS][COLUMNS];

        for(int row = 0; row < ROWS; row++) {
			for(int col = 0; col < COLUMNS; col++) {
				board[row][col] = EMPTY;
			}
		}
    }

	public Board(int[][] board) {
        this.board = board;
    }

	public boolean canMove(int row, int col) {
		if (row < 0 || row >= ROWS) {
			return false;
		}

		if (col < 0 || col >= COLUMNS) {
			return false;
		}

		return true;
	}

	public boolean checkFullColumn(int col) {
		return board[0][col] != EMPTY;
	}

	public int makeMove(int column, int player) {
		if (column < 0 || column >= COLUMNS) {
			return -1;
		}

		if (checkFullColumn(column)) {
			return -1;
		}

        for (int row = ROWS - 1; row >= 0; row--) {
            if (board[row][column] == EMPTY) {
                board[row][column] = player;
                return row;
            }
        }

		return -1;
    }

	public void setWinner(int player) {
		winner = player;
	}

	public int getWinner() {
		return winner;
	}

	public boolean checkForDraw() {
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLUMNS; col++) {
				if (board[row][col] == EMPTY) {
					return false;
				}
			}
		}

		winner = EMPTY;
		return true;
	}

	public int countStreaks(int streaks, int player) {
		int times = 0;

		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLUMNS; col++) {
				if (canMove(row, col + 3)) {
					int counter = 0;
					int find = 0;
					
					while (counter < streaks && board[row][col + counter] == player) {
						counter++;
					}

					if (counter == 4) {
						times++;
						return times;
					}

					if (streaks < 4) {
						while (counter < 4 && (board[row][col + counter] == player || board[row][col + counter] == EMPTY)) {
							if (board[row][col + counter] == player) {
								find = 1;
							}
							counter++;
						}

						if (counter == 4 && find == 1) {
							times++;
						}
					}
				}
			}
		}

		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLUMNS; col++) {
				if (canMove(row - 3, col)) {
					int counter = 0;
					int find = 0;

					while (counter < streaks && board[row - counter][col] == player) {
						counter++;
					}

					if (counter == 4) {
						times++;
						return times;
					}

					if (streaks < 4) {
						while (counter < 4 && (board[row - counter][col] == player || board[row - counter][col] == EMPTY)) {
							if (board[row - counter][col] == player) {
								find = 1;
							}

							counter++;
						}

						if (counter == 4 && find == 1) {
							times++;
						}
					}
				}
			}
		}

		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLUMNS; col++) {
				if (canMove(row + 3, col + 3)) {
					int counter = 0;
					int find = 0;

					while (counter < streaks && board[row + counter][col + counter] == player) {
						counter++;
					}
					
					if (counter == 4) {
						times++;
						return times;
					}

					if (streaks < 4) {
						while (counter < 4 && (board[row + counter][col + counter] == player || board[row + counter][col + counter] == EMPTY)) {
							if (board[row + counter][col + counter] == player) {
								find = 1;
							}
						
							counter++;
						}

						if (counter == 4 && find == 1) {
							times++;
						}
					}
				}
			}
		}

		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLUMNS; col++) {
				if (canMove(row - 3, col + 3)) {
					int counter = 0;
					int find = 0;

					while (counter < streaks && board[row - counter][col + counter] == player) {
						counter++;
					}

					if (counter == 4) {
						times++;
						return times;
					}

					if (streaks < 4) {
						while (counter < 4 && (board[row - counter][col + counter] == player || board[row - counter][col + counter] == EMPTY)) {
							if (board[row - counter][col + counter] == player) {
								find = 1;
							}

							counter++;
						}
					
						if (counter == 4 && find == 1) {
							times++;
						}
					}
				}
			}
		}

		return times;
	}

	public boolean checkForWinner() {
		int counter = countStreaks(4, RED);
		
		if (counter > 0) {
			setWinner(RED);
			return true;
		}

		counter = countStreaks(4, YELLOW);
		if (counter > 0) {
			setWinner(YELLOW);
			return true;
		}

		setWinner(EMPTY);
		return false;
	}

	public boolean isGameOver() {
        if (checkForWinner()) {
			return true;
		}

		return checkForDraw();
    }

	public Board cloneBoard() {
		int[][] new_board = new int[ROWS][COLUMNS];

        for(int row = 0; row < ROWS; row++) {
			for(int col = 0; col < COLUMNS; col++) {
				new_board[row][col] = board[row][col];
			}
		}

		return new Board(new_board);
	}

	public void resetBoard() {
		for(int row = 0; row < ROWS; row++) {
			for(int col = 0; col < COLUMNS; col++) {
				board[row][col] = EMPTY;
			}
		}
	}

	private String getBoardAsString() {
		StringBuilder output = new StringBuilder();
		output.append("\n|");
		for (int col = 0; col < COLUMNS; col++) {
			output.append(" ").append(col).append(" |");
		}
		output.append("\n");
		output.append("-----------------------------\n");
		
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLUMNS; col++) {
				char symbol = '-';
				if (board[row][col] == RED) {
					symbol = 'X';
				} else if (board[row][col] == YELLOW) {
					symbol = 'O';
				}
				output.append("| ").append(symbol).append(" ");
				if (col == COLUMNS - 1) {
					output.append("|\n");
				}
			}
		}

		output.append("-----------------------------\n\n");

		return output.toString();
	}

	public void displayBoard() {
		System.out.print(getBoardAsString());
	}
}

